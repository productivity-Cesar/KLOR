// Copyright 2022 @geigeigeist
// SPDX-License-Identifier: GPL-2.0+

#include "2040.h"